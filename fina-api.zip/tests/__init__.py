"""FinaAPI tests."""
