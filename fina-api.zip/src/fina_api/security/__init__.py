"""Authentication and authorization helpers."""
