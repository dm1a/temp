"""Kubernetes-only HTTP endpoints."""
